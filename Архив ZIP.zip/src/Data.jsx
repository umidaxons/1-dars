export const userList = [
  {
    name: "yousaf khan",
    email: "yousaft1@gmail.com",
    id: 1,
  },
  {
     name: "yousaf khan",
    email: "yousaft1@gmail.com",
    id: 2,
  },
  {
     name: "yousaf khan",
    email: "yousaft1@gmail.com",
    id: 3,
  },
];
